///////////////////////////////////////////////////////////////////////////////
// ViewManager.cpp
// Camera navigation, mouse look, scrolling, and projection switching for
// CS 330 final project. Based on the supplied SNHU ViewManager starter code.
///////////////////////////////////////////////////////////////////////////////

#include "ViewManager.h"

#include <iostream>
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>

namespace
{
    const int WINDOW_WIDTH = 1000;
    const int WINDOW_HEIGHT = 800;
    const char* g_ViewName = "view";
    const char* g_ProjectionName = "projection";

    Camera* g_pCamera = nullptr;

    float gLastX = WINDOW_WIDTH / 2.0f;
    float gLastY = WINDOW_HEIGHT / 2.0f;
    bool gFirstMouse = true;

    float gDeltaTime = 0.0f;
    float gLastFrame = 0.0f;
    // Normal wheel adjusts traversal speed to satisfy the rubric.
    // Ctrl+wheel retains the earlier zoom functionality.
    float gMovementSpeedScale = 1.0f;

    // Perspective is the initial projection. O selects orthographic, P selects perspective.
    bool bOrthographicProjection = false;
    float gOrthoHalfHeight = 9.0f;

    // Wheel = camera movement speed; Ctrl+wheel = optical / orthographic zoom.
    // This keeps the previous zoom feature but honors the required scroll control.
    void MouseScrollCallback(GLFWwindow* window, double xoffset, double yoffset)
    {
        (void)xoffset;
        if (g_pCamera == nullptr)
        {
            return;
        }

        const bool zoomModifier =
            glfwGetKey(window, GLFW_KEY_LEFT_CONTROL) == GLFW_PRESS ||
            glfwGetKey(window, GLFW_KEY_RIGHT_CONTROL) == GLFW_PRESS;

        if (!zoomModifier)
        {
            gMovementSpeedScale = glm::clamp(
                gMovementSpeedScale + 0.20f * static_cast<float>(yoffset),
                0.25f, 4.0f);
            return;
        }

        if (bOrthographicProjection)
        {
            gOrthoHalfHeight = glm::clamp(
                gOrthoHalfHeight - static_cast<float>(yoffset), 3.0f, 25.0f);
        }
        else
        {
            g_pCamera->ProcessMouseScroll(static_cast<float>(yoffset));
        }
    }
}

ViewManager::ViewManager(ShaderManager* pShaderManager)
{
    m_pShaderManager = pShaderManager;
    m_pWindow = nullptr;
    g_pCamera = new Camera();

    // Start from a front/right vantage to show the complete reference-photo scene.
    // Keep camera angles consistent with the initial Front vector so mouse
    // movement does not abruptly change the view direction.
    g_pCamera->Position = glm::vec3(0.70f, 2.0f, 13.5f);
    g_pCamera->Yaw = -93.0f;
    g_pCamera->Pitch = -9.0f;
    g_pCamera->ProcessMouseMovement(0.0f, 0.0f);
    g_pCamera->Zoom = 55.0f;
}

ViewManager::~ViewManager()
{
    m_pShaderManager = nullptr;
    m_pWindow = nullptr;
    delete g_pCamera;
    g_pCamera = nullptr;
}

GLFWwindow* ViewManager::CreateDisplayWindow(const char* windowTitle)
{
    GLFWwindow* window = glfwCreateWindow(
        WINDOW_WIDTH, WINDOW_HEIGHT, windowTitle, nullptr, nullptr);
    if (window == nullptr)
    {
        std::cout << "Failed to create GLFW window" << std::endl;
        glfwTerminate();
        return nullptr;
    }

    glfwMakeContextCurrent(window);

    // Hold the right mouse button and drag to turn the camera.
    // This avoids locking the cursor while the student uses Visual Studio.
    glfwSetCursorPosCallback(window, &ViewManager::Mouse_Position_Callback);
    glfwSetScrollCallback(window, MouseScrollCallback);

    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    m_pWindow = window;
    return window;
}

void ViewManager::Mouse_Position_Callback(
    GLFWwindow* window, double xMousePos, double yMousePos)
{
    if (g_pCamera == nullptr)
    {
        return;
    }

    // Only rotate when the right mouse button is held.
    if (glfwGetMouseButton(window, GLFW_MOUSE_BUTTON_RIGHT) != GLFW_PRESS)
    {
        gFirstMouse = true;
        return;
    }

    if (gFirstMouse)
    {
        gLastX = static_cast<float>(xMousePos);
        gLastY = static_cast<float>(yMousePos);
        gFirstMouse = false;
        return;
    }

    const float xoffset = static_cast<float>(xMousePos) - gLastX;
    const float yoffset = gLastY - static_cast<float>(yMousePos);
    gLastX = static_cast<float>(xMousePos);
    gLastY = static_cast<float>(yMousePos);

    g_pCamera->ProcessMouseMovement(xoffset, yoffset);
}

void ViewManager::ProcessKeyboardEvents()
{
    if (m_pWindow == nullptr || g_pCamera == nullptr)
    {
        return;
    }

    if (glfwGetKey(m_pWindow, GLFW_KEY_ESCAPE) == GLFW_PRESS)
    {
        glfwSetWindowShouldClose(m_pWindow, true);
    }

    // The camera class uses delta time so movement is frame-rate independent.
    const float speedFactor =
        (glfwGetKey(m_pWindow, GLFW_KEY_LEFT_SHIFT) == GLFW_PRESS) ? 2.0f : 1.0f;
    const float movementDelta = gDeltaTime * speedFactor * gMovementSpeedScale;

    if (glfwGetKey(m_pWindow, GLFW_KEY_W) == GLFW_PRESS)
        g_pCamera->ProcessKeyboard(FORWARD, movementDelta);
    if (glfwGetKey(m_pWindow, GLFW_KEY_S) == GLFW_PRESS)
        g_pCamera->ProcessKeyboard(BACKWARD, movementDelta);
    if (glfwGetKey(m_pWindow, GLFW_KEY_A) == GLFW_PRESS)
        g_pCamera->ProcessKeyboard(LEFT, movementDelta);
    if (glfwGetKey(m_pWindow, GLFW_KEY_D) == GLFW_PRESS)
        g_pCamera->ProcessKeyboard(RIGHT, movementDelta);

    // Vertical movement in world space: Q = down, E = up.
    const float verticalDistance = 3.0f * movementDelta;
    if (glfwGetKey(m_pWindow, GLFW_KEY_Q) == GLFW_PRESS)
        g_pCamera->Position.y -= verticalDistance;
    if (glfwGetKey(m_pWindow, GLFW_KEY_E) == GLFW_PRESS)
        g_pCamera->Position.y += verticalDistance;

    // Direct assignments (rather than toggles) avoid key repeat flickering.
    if (glfwGetKey(m_pWindow, GLFW_KEY_O) == GLFW_PRESS)
        bOrthographicProjection = true;
    if (glfwGetKey(m_pWindow, GLFW_KEY_P) == GLFW_PRESS)
        bOrthographicProjection = false;
}

void ViewManager::PrepareSceneView()
{
    if (m_pWindow == nullptr || g_pCamera == nullptr)
    {
        return;
    }

    const float currentFrame = static_cast<float>(glfwGetTime());
    gDeltaTime = currentFrame - gLastFrame;
    gLastFrame = currentFrame;
    ProcessKeyboardEvents();

    int framebufferWidth = 0;
    int framebufferHeight = 0;
    glfwGetFramebufferSize(m_pWindow, &framebufferWidth, &framebufferHeight);
    if (framebufferWidth <= 0 || framebufferHeight <= 0)
    {
        return;
    }
    glViewport(0, 0, framebufferWidth, framebufferHeight);

    const float aspectRatio =
        static_cast<float>(framebufferWidth) / static_cast<float>(framebufferHeight);
    const glm::mat4 view = g_pCamera->GetViewMatrix();
    glm::mat4 projection(1.0f);

    if (bOrthographicProjection)
    {
        const float halfWidth = gOrthoHalfHeight * aspectRatio;
        projection = glm::ortho(
            -halfWidth, halfWidth,
            -gOrthoHalfHeight, gOrthoHalfHeight,
            0.1f, 100.0f);
    }
    else
    {
        projection = glm::perspective(
            glm::radians(g_pCamera->Zoom), aspectRatio, 0.1f, 100.0f);
    }

    if (m_pShaderManager != nullptr)
    {
        m_pShaderManager->setMat4Value(g_ViewName, view);
        m_pShaderManager->setMat4Value(g_ProjectionName, projection);
        m_pShaderManager->setVec3Value("viewPosition", g_pCamera->Position);
    }
}
