///////////////////////////////////////////////////////////////////////////////
// shadermanager.cpp
// ============
// manage the loading and rendering of 3D scenes
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager *pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();
	m_loadedTextures = 0; // Initialize before registering textures
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	DestroyGLTextures();
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			stbi_image_free(image);
			glDeleteTextures(1, &textureID);
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glDeleteTextures(1, &m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	std::size_t index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.ambientColor = m_objectMaterials[index].ambientColor;
			material.ambientStrength = m_objectMaterials[index].ambientStrength;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(bFound);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationX * rotationY * rotationZ * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		const int textureSlot = FindTextureSlot(textureTag);
		if (textureSlot < 0)
		{
			// A missing texture is safer to render as a plain color.
			m_pShaderManager->setIntValue(g_UseTextureName, false);
			return;
		}
		m_pShaderManager->setIntValue(g_UseTextureName, true);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureSlot);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.ambientColor", material.ambientColor);
			m_pShaderManager->setFloatValue("material.ambientStrength", material.ambientStrength);
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/


/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene 
 *  rendering
 ***********************************************************/
void SceneManager::PrepareScene()
{
	// Load each primitive once for reuse throughout the furnished scene.
	m_basicMeshes->LoadPlaneMesh();
	m_basicMeshes->LoadCylinderMesh();
	m_basicMeshes->LoadConeMesh();
	m_basicMeshes->LoadSphereMesh();
	// Furniture, desk accessories, and the plant complete the scene.
	// All nine primitive mesh families are loaded below.
	m_basicMeshes->LoadBoxMesh();
	m_basicMeshes->LoadTorusMesh();
	// Rubric: ensure all nine required primitive families are used.
	m_basicMeshes->LoadPrismMesh();
	m_basicMeshes->LoadPyramid4Mesh();
	m_basicMeshes->LoadTaperedCylinderMesh();

	// Reuse the existing JPG assets from CS330Content/Utilities/textures.
	// Paths match MainCode.cpp, which loads ../../Utilities/shaders/...
	// from the Visual Studio project Debug working directory.
	CreateGLTexture("../../Utilities/textures/rusticwood.jpg", "deskWood");
	CreateGLTexture("../../Utilities/textures/stainless.jpg", "brushedMetal");
	CreateGLTexture("../../Utilities/textures/gold-seamless-texture.jpg", "shadeFabric");
	BindGLTextures();

	// Materials describe how the different surfaces reflect light.
	m_objectMaterials.clear();
	OBJECT_MATERIAL wood;
	wood.tag = "wood";
	wood.ambientStrength = 0.75f;
	wood.ambientColor = glm::vec3(1.0f, 0.95f, 0.85f);
	wood.diffuseColor = glm::vec3(1.0f, 0.96f, 0.90f);
	wood.specularColor = glm::vec3(0.12f, 0.10f, 0.08f);
	wood.shininess = 16.0f;
	m_objectMaterials.push_back(wood);

	OBJECT_MATERIAL metal;
	metal.tag = "metal";
	metal.ambientStrength = 0.75f;
	metal.ambientColor = glm::vec3(0.90f, 0.93f, 1.0f);
	metal.diffuseColor = glm::vec3(0.80f, 0.86f, 0.94f);
	metal.specularColor = glm::vec3(0.70f, 0.73f, 0.78f);
	metal.shininess = 64.0f;
	m_objectMaterials.push_back(metal);

	OBJECT_MATERIAL shade;
	shade.tag = "shade";
	shade.ambientStrength = 0.85f;
	shade.ambientColor = glm::vec3(1.0f, 0.94f, 0.72f);
	shade.diffuseColor = glm::vec3(1.0f, 0.90f, 0.58f);
	shade.specularColor = glm::vec3(0.10f, 0.08f, 0.04f);
	shade.shininess = 9.0f;
	m_objectMaterials.push_back(shade);

	// Material presets for the additional desk accessories.
	// Colored book covers and pencil paint should look mostly matte.
	OBJECT_MATERIAL matte;
	matte.tag = "matte";
	matte.ambientStrength = 0.78f;
	matte.ambientColor = glm::vec3(1.0f, 1.0f, 1.0f);
	matte.diffuseColor = glm::vec3(0.92f, 0.92f, 0.92f);
	matte.specularColor = glm::vec3(0.08f, 0.08f, 0.08f);
	matte.shininess = 8.0f;
	m_objectMaterials.push_back(matte);

	// Soft white pages are less shiny than the glazed ceramic mug.
	OBJECT_MATERIAL paper = matte;
	paper.tag = "paper";
	paper.ambientStrength = 0.90f;
	paper.diffuseColor = glm::vec3(1.0f, 0.99f, 0.92f);
	paper.specularColor = glm::vec3(0.015f, 0.015f, 0.015f);
	paper.shininess = 2.0f;
	m_objectMaterials.push_back(paper);

	OBJECT_MATERIAL ceramic = matte;
	ceramic.tag = "ceramic";
	ceramic.ambientStrength = 0.85f;
	ceramic.diffuseColor = glm::vec3(1.0f, 1.0f, 1.0f);
	ceramic.specularColor = glm::vec3(0.60f, 0.60f, 0.58f);
	ceramic.shininess = 50.0f;
	m_objectMaterials.push_back(ceramic);

	OBJECT_MATERIAL coffee = matte;
	coffee.tag = "coffee";
	coffee.ambientStrength = 0.55f;
	coffee.diffuseColor = glm::vec3(0.68f, 0.52f, 0.40f);
	coffee.specularColor = glm::vec3(0.40f, 0.33f, 0.25f);
	coffee.shininess = 32.0f;
	m_objectMaterials.push_back(coffee);

	// Daylight directional light fills the desk, including the undershelf.
	// Warm point light comes from the silver desk lamp (two lighting types).
	m_pShaderManager->setIntValue(g_UseLightingName, true);
	m_pShaderManager->setVec3Value("dirLight.direction", glm::vec3(-0.48f, -0.90f, -0.35f));
	m_pShaderManager->setVec3Value("dirLight.ambient", glm::vec3(0.62f, 0.62f, 0.62f));
	m_pShaderManager->setVec3Value("dirLight.diffuse", glm::vec3(0.62f, 0.61f, 0.57f));
	m_pShaderManager->setVec3Value("dirLight.specular", glm::vec3(0.33f, 0.34f, 0.37f));

	m_pShaderManager->setVec3Value("pointLight.position", glm::vec3(2.55f, 3.62f, -2.55f));
	m_pShaderManager->setVec3Value("pointLight.ambient", glm::vec3(0.15f, 0.13f, 0.11f));
	m_pShaderManager->setVec3Value("pointLight.diffuse", glm::vec3(0.65f, 0.58f, 0.47f));
	m_pShaderManager->setVec3Value("pointLight.specular", glm::vec3(0.72f, 0.67f, 0.60f));
	m_pShaderManager->setFloatValue("pointLight.constant", 1.0f);
	m_pShaderManager->setFloatValue("pointLight.linear", 0.09f);
	m_pShaderManager->setFloatValue("pointLight.quadratic", 0.032f);
}

/***********************************************************
 *  RenderScene()
 *
 *  The lamp uses multiple transformed 3D primitives, with
 *  independently textured materials and two lighting sources.
 ***********************************************************/
void SceneManager::RenderScene()
{
    // Scene derived from the student's Milestone One photo: a white study
    // desk, open shelves, white chair, silver lamp, black mug, papers,
    // books, a small memo holder, and a plant by a window.
    // All 9 rubric primitive mesh families are reused in this scene.
    enum class Mesh { Box, Plane, Cylinder, Cone, Sphere, Torus,
                      Prism, Pyramid, TaperedCylinder };

    // Reusable primitive renderer centralizes UV, color, material, and model
    // transformations. The object builders below call this one function.
    auto draw = [&](Mesh mesh, const glm::vec3& size,
                    const glm::vec3& at, const glm::vec4& color,
                    const char* material = "matte",
                    const char* texture = nullptr,
                    float rx = 0.0f, float ry = 0.0f, float rz = 0.0f,
                    float u = 1.0f, float v = 1.0f)
    {
        SetTransformations(size, rx, ry, rz, at);
        SetTextureUVScale(u, v);
        SetShaderColor(color.r, color.g, color.b, color.a);
        if (texture != nullptr && FindTextureSlot(texture) >= 0)
            SetShaderTexture(texture);
        SetShaderMaterial(material);
        switch (mesh)
        {
        case Mesh::Box:             m_basicMeshes->DrawBoxMesh(); break;
        case Mesh::Plane:           m_basicMeshes->DrawPlaneMesh(); break;
        case Mesh::Cylinder:        m_basicMeshes->DrawCylinderMesh(); break;
        case Mesh::Cone:            m_basicMeshes->DrawConeMesh(); break;
        case Mesh::Sphere:          m_basicMeshes->DrawSphereMesh(); break;
        case Mesh::Torus:           m_basicMeshes->DrawTorusMesh(); break;
        case Mesh::Prism:           m_basicMeshes->DrawPrismMesh(); break;
        case Mesh::Pyramid:         m_basicMeshes->DrawPyramid4Mesh(); break;
        case Mesh::TaperedCylinder: m_basicMeshes->DrawTaperedCylinderMesh(); break;
        }
    };

    const glm::vec4 white(0.94f, 0.94f, 0.90f, 1.0f);
    const glm::vec4 cream(0.91f, 0.89f, 0.83f, 1.0f);
    const glm::vec4 silver(0.73f, 0.76f, 0.79f, 1.0f);
    const glm::vec4 charcoal(0.14f, 0.15f, 0.16f, 1.0f);
    const glm::vec4 ink(0.12f, 0.13f, 0.14f, 1.0f);
    const glm::vec4 paper(0.98f, 0.97f, 0.94f, 1.0f);

    // Room background. A textured brown floor contrasts with the white
    // furniture; the white/grey wall and window approximate the photograph.
    draw(Mesh::Plane, glm::vec3(18.0f, 1.0f, 18.0f),
         glm::vec3(0.0f, -3.13f, 0.0f), glm::vec4(0.55f, 0.38f, 0.22f, 1),
         "wood", "deskWood", 0, 0, 0, 4.0f, 4.0f);
    draw(Mesh::Box, glm::vec3(16.0f, 10.0f, 0.24f),
         glm::vec3(0.0f, 1.95f, -5.38f),
         glm::vec4(0.75f, 0.72f, 0.66f, 1.0f));
    // A dark wardrobe/panel sits along the right edge, as in the reference.
    draw(Mesh::Box, glm::vec3(2.20f, 10.0f, 0.48f),
         glm::vec3(5.58f, 1.95f, -5.00f),
         glm::vec4(0.25f, 0.26f, 0.25f, 1.0f));

    // Bright left-side window: pale glass framed by four white molding bars.
    draw(Mesh::Box, glm::vec3(6.35f, 3.20f, 0.06f),
         glm::vec3(-2.30f, 4.55f, -5.18f),
         glm::vec4(0.84f, 0.91f, 0.90f, 1.0f), "paper");
    draw(Mesh::Box, glm::vec3(6.60f, 0.16f, 0.33f),
         glm::vec3(-2.30f, 2.94f, -5.02f), white);
    draw(Mesh::Box, glm::vec3(6.60f, 0.15f, 0.33f),
         glm::vec3(-2.30f, 6.14f, -5.02f), white);
    for (float x : {-5.60f, -2.30f, 1.00f})
        draw(Mesh::Box, glm::vec3(0.16f, 3.20f, 0.32f),
             glm::vec3(x, 4.55f, -5.02f), white);
    draw(Mesh::Box, glm::vec3(7.10f, 0.20f, 0.78f),
         glm::vec3(-2.30f, 2.78f, -4.76f), white);

    // White compact study desk: a top, four square legs, an open shelf,
    // and thin front rails. Multiple box and cylinder meshes compose it.
    auto drawDesk = [&]()
    {
        draw(Mesh::Box, glm::vec3(8.0f, 0.26f, 3.90f),
             glm::vec3(-0.45f, 0.86f, -1.18f), white, "ceramic");
        for (float x : {-4.25f, 3.35f})
        for (float z : {-2.93f, 0.58f})
        {
            draw(Mesh::Box, glm::vec3(0.28f, 3.70f, 0.29f),
                 glm::vec3(x, -1.12f, z), white, "matte");
            // Little cylindrical caps are visible at the feet.
            draw(Mesh::Cylinder, glm::vec3(0.19f, 0.10f, 0.19f),
                 glm::vec3(x, -3.04f, z), silver, "metal");
        }
        draw(Mesh::Box, glm::vec3(7.45f, 0.14f, 3.45f),
             glm::vec3(-0.45f, -0.66f, -1.17f), white);
        draw(Mesh::Box, glm::vec3(7.65f, 0.44f, 0.18f),
             glm::vec3(-0.45f, 0.49f, 0.71f), white);
        draw(Mesh::Box, glm::vec3(7.65f, 0.23f, 0.18f),
             glm::vec3(-0.45f, -0.20f, 0.71f), white);
        draw(Mesh::Box, glm::vec3(0.16f, 3.35f, 0.16f),
             glm::vec3(-0.45f, -1.18f, -2.94f), white);
    };
    drawDesk();

    // Books on the open shelf, NOT stacked on the tabletop (photo fidelity).
    auto drawBook = [&](const glm::vec3& at, float width, float depth,
                        const glm::vec4& coverColor)
    {
        draw(Mesh::Box, glm::vec3(width, 0.065f, depth),
             glm::vec3(at.x, at.y, at.z), coverColor);
        draw(Mesh::Box, glm::vec3(width - 0.10f, 0.17f, depth - 0.08f),
             glm::vec3(at.x, at.y + 0.12f, at.z), cream, "paper");
        draw(Mesh::Box, glm::vec3(width, 0.065f, depth),
             glm::vec3(at.x, at.y + 0.23f, at.z), coverColor);
    };
    drawBook(glm::vec3(-2.25f, -0.52f, -1.06f), 2.10f, 1.45f,
             glm::vec4(0.55f, 0.45f, 0.35f, 1));
    drawBook(glm::vec3(1.15f, -0.52f, -1.23f), 2.25f, 1.40f,
             glm::vec4(0.27f, 0.43f, 0.47f, 1));

    // A white chair is pulled out in front of the right-hand side.
    // Four legs, the seat, rear pillars, two back rails, and rounded
    // cylinder feet make this a reusable composite object.
    auto drawChair = [&]()
    {
        const float cx = 3.05f;
        const float cz = 2.72f;
        draw(Mesh::Box, glm::vec3(2.92f, 0.23f, 2.55f),
             glm::vec3(cx, -1.18f, cz), white, "ceramic");
        for (float x : {cx - 1.13f, cx + 1.13f})
        for (float z : {cz - 0.96f, cz + 0.97f})
        {
            draw(Mesh::Box, glm::vec3(0.20f, 1.82f, 0.20f),
                 glm::vec3(x, -2.14f, z), white);
            draw(Mesh::Cylinder, glm::vec3(0.11f, 0.08f, 0.11f),
                 glm::vec3(x, -3.12f, z), silver, "metal");
        }
        for (float x : {cx - 1.23f, cx + 1.23f})
            draw(Mesh::Box, glm::vec3(0.24f, 2.14f, 0.24f),
                 glm::vec3(x, -0.02f, cz + 1.12f), white);
        draw(Mesh::Box, glm::vec3(2.68f, 0.47f, 0.20f),
             glm::vec3(cx, 0.82f, cz + 1.12f), white);
        draw(Mesh::Box, glm::vec3(2.50f, 0.18f, 0.20f),
             glm::vec3(cx, -0.15f, cz + 1.12f), white);
    };
    drawChair();

    // Small silver adjustable lamp near the back-right of the desk.
    auto drawLamp = [&]()
    {
        const float x = 2.33f, z = -2.40f;
        draw(Mesh::Cylinder, glm::vec3(0.54f, 0.14f, 0.54f),
             glm::vec3(x, 1.00f, z), silver, "metal", "brushedMetal");
        draw(Mesh::Cylinder, glm::vec3(0.080f, 2.22f, 0.080f),
             glm::vec3(x, 1.13f, z), silver, "metal", "brushedMetal");
        draw(Mesh::Sphere, glm::vec3(0.14f, 0.14f, 0.14f),
             glm::vec3(x, 3.37f, z), silver, "metal", "brushedMetal");
        draw(Mesh::Cylinder, glm::vec3(0.068f, 0.83f, 0.068f),
             glm::vec3(x - 0.03f, 3.40f, z), silver, "metal", "brushedMetal",
             0.0f, 0.0f, 18.0f);
        draw(Mesh::Cone, glm::vec3(0.51f, 0.46f, 0.51f),
             glm::vec3(x - 0.14f, 3.99f, z), silver, "metal", "brushedMetal",
             180.0f, 0.0f, 0.0f);
    };
    drawLamp();

    // Black ceramic mug with coffee, tapered cylinder and two torus rims.
    auto drawMug = [&]()
    {
        const float x = 3.16f, z = -0.48f;
        draw(Mesh::TaperedCylinder, glm::vec3(0.41f, 0.76f, 0.41f),
             glm::vec3(x, 0.99f, z), charcoal, "ceramic");
        draw(Mesh::Cylinder, glm::vec3(0.34f, 0.018f, 0.34f),
             glm::vec3(x, 1.755f, z),
             glm::vec4(0.13f, 0.08f, 0.05f, 1), "coffee");
        draw(Mesh::Torus, glm::vec3(0.425f, 0.057f, 0.425f),
             glm::vec3(x, 1.77f, z), charcoal, "ceramic");
        draw(Mesh::Torus, glm::vec3(0.30f, 0.33f, 0.18f),
             glm::vec3(x + 0.46f, 1.36f, z), charcoal, "ceramic",
             nullptr, 90.0f);
    };
    drawMug();

    // Center notebook with a dark cover and a small notebook binding.
    draw(Mesh::Box, glm::vec3(2.15f, 0.085f, 1.48f),
         glm::vec3(0.75f, 1.04f, -1.18f), charcoal);
    draw(Mesh::Box, glm::vec3(2.02f, 0.028f, 1.37f),
         glm::vec3(0.75f, 1.091f, -1.18f),
         glm::vec4(0.24f, 0.26f, 0.27f, 1.0f));
    for (int i = 0; i < 6; ++i)
        draw(Mesh::Cylinder, glm::vec3(0.029f, 0.10f, 0.029f),
             glm::vec3(-0.28f, 1.04f, -1.75f + 0.21f * i), silver,
             "metal", nullptr, 90.0f);

    // Loose papers and a pen on the left-hand side of the tabletop.
    draw(Mesh::Box, glm::vec3(2.33f, 0.026f, 1.54f),
         glm::vec3(-2.05f, 1.014f, -0.88f), paper, "paper", nullptr,
         0.0f, 5.0f);
    draw(Mesh::Box, glm::vec3(2.25f, 0.018f, 1.50f),
         glm::vec3(-2.08f, 1.035f, -0.93f), cream, "paper", nullptr,
         0.0f, -3.0f);
    draw(Mesh::Cylinder, glm::vec3(0.037f, 1.30f, 0.037f),
         glm::vec3(-1.95f, 1.06f, -0.94f), silver, "metal",
         nullptr, 90.0f, 0.0f, 25.0f);
    draw(Mesh::Cone, glm::vec3(0.048f, 0.12f, 0.048f),
         glm::vec3(-1.65f, 1.08f, -1.34f), ink, "matte",
         nullptr, 90.0f, 0.0f, 25.0f);

    // Yellow note in a silver wire clip on the far-left corner.
    // The prism foot and pyramid clamp make the two extra rubric mesh
    // types visually meaningful rather than arbitrary decorations.
    draw(Mesh::Prism, glm::vec3(0.52f, 0.18f, 0.40f),
         glm::vec3(-3.48f, 1.0f, -2.40f), silver, "metal", "brushedMetal");
    draw(Mesh::Cylinder, glm::vec3(0.040f, 1.08f, 0.040f),
         glm::vec3(-3.48f, 1.10f, -2.40f), silver, "metal");
    draw(Mesh::Sphere, glm::vec3(0.12f, 0.12f, 0.12f),
         glm::vec3(-3.48f, 2.22f, -2.40f), silver, "metal");
    draw(Mesh::Pyramid, glm::vec3(0.22f, 0.28f, 0.22f),
         glm::vec3(-3.48f, 2.27f, -2.40f), silver, "metal");
    draw(Mesh::Box, glm::vec3(0.83f, 0.70f, 0.035f),
         glm::vec3(-3.48f, 2.60f, -2.34f),
         glm::vec4(0.93f, 0.77f, 0.23f, 1.0f), "paper");

    // White ceramic plant pot on the window sill and green low-poly leaves.
    // The plant adds visual balance to the upper-left of the image.
    draw(Mesh::TaperedCylinder, glm::vec3(0.48f, 0.65f, 0.48f),
         glm::vec3(-1.28f, 2.93f, -4.60f), white, "ceramic");
    draw(Mesh::Torus, glm::vec3(0.47f, 0.055f, 0.47f),
         glm::vec3(-1.28f, 3.60f, -4.60f), white, "ceramic");
    draw(Mesh::Cylinder, glm::vec3(0.39f, 0.016f, 0.39f),
         glm::vec3(-1.28f, 3.61f, -4.60f),
         glm::vec4(0.17f, 0.12f, 0.08f, 1.0f));
    const glm::vec4 leaf(0.20f, 0.37f, 0.24f, 1.0f);
    for (float offset : {-0.33f, 0.0f, 0.33f})
    {
        draw(Mesh::Sphere, glm::vec3(0.34f, 0.39f, 0.33f),
             glm::vec3(-1.28f + offset, 3.94f, -4.58f), leaf);
        draw(Mesh::Cone, glm::vec3(0.30f, 0.47f, 0.30f),
             glm::vec3(-1.28f + offset, 4.13f, -4.58f), leaf);
    }
}
